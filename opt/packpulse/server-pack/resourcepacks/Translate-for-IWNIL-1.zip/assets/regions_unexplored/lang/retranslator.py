import json


def merge_by_template(en, ru):
    if isinstance(en, dict):
        result = {}
        for key, en_value in en.items():
            if key in ru:
                if isinstance(en_value, dict) and isinstance(ru[key], dict):
                    result[key] = merge_by_template(en_value, ru[key])
                else:
                    result[key] = ru[key]
            else:
                result[key] = en_value
        return result

    return ru if ru is not None else en


with open("en_us.json", "r", encoding="utf-8") as f:
    en = json.load(f)

with open("ru_ru.json", "r", encoding="utf-8") as f:
    ru = json.load(f)

merged = merge_by_template(en, ru)

with open("ru_ru2.json", "w", encoding="utf-8") as f:
    json.dump(merged, f, ensure_ascii=False, indent=4)

print("Готово.")